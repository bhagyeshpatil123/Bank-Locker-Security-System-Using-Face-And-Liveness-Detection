from django.apps import AppConfig


class FaceappConfig(AppConfig):
    name = 'faceapp'
